"""
Simple RDKit featurizer placeholder.

Replace and expand with real descriptor functions used in the notebook.
"""
from rdkit import Chem
from rdkit.Chem import Descriptors

def mol_from_smiles(smiles):
    return Chem.MolFromSmiles(smiles)

def descriptor_vector(smiles):
    mol = mol_from_smiles(smiles)
    if mol is None:
        return None
    return {
        "MolWt": Descriptors.MolWt(mol),
        "LogP": Descriptors.MolLogP(mol),
        "TPSA": Descriptors.TPSA(mol),
        "NumHDonors": Descriptors.NumHDonors(mol),
        "NumHAcceptors": Descriptors.NumHAcceptors(mol),
    }
