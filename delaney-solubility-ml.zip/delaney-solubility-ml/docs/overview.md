# Project overview

This folder can host rendered figures, experiment logs, and documentation.