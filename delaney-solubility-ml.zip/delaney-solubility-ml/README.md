# Delaney Solubility Prediction — Machine Learning with RDKit

This repository contains a complete, reproducible workflow for predicting aqueous solubility (LogS) of organic molecules using classical machine-learning algorithms and molecular descriptors generated with **RDKit**.

## Repository snapshot
- Notebook: `notebooks/Delaney_solubility.ipynb` (original notebook included if available)
- Structure: `data/`, `notebooks/`, `src/`, `docs/`, `tests/`

## Quickstart

1. Clone the repo:
```bash
git clone https://github.com/<your-username>/delaney-solubility-ml.git
cd delaney-solubility-ml
```

2. Create a Python environment (recommended):
```bash
python -m venv .venv
source .venv/bin/activate    # macOS / Linux
.venv\Scripts\activate     # Windows (PowerShell)
pip install -r requirements.txt
```

3. Start Jupyter and open the notebook:
```bash
jupyter notebook
```

## What this project contains

- A Jupyter notebook that demonstrates:
  - Loading the ESOL (Delaney) dataset
  - Featurizing molecules with RDKit descriptors
  - Building scikit-learn pipelines
  - Training and evaluating regression models (Linear Regression, Random Forest, etc.)
  - Visualizations and model comparison

## Files included
- `README.md` — this file
- `requirements.txt` — Python dependencies
- `LICENSE` — MIT (replace author name)
- `.gitignore` — recommended ignores for Python projects
- `notebooks/Delaney_solubility.ipynb` — original notebook (if present)
- `src/` — place for reusable modules (featurizers, model wrappers)
- `data/` — place to store CSVs or datasets
- `docs/` — optional documentation, experiments, figures
- `tests/` — unit / integration tests

## Recommended next steps
- Replace `<your-username>` in the clone URL with your GitHub username.
- Add GitHub Actions workflow for CI (tests + linting).
- Add `examples/` or `notebooks/` with rendered outputs (NBViewer / GitHub).
- Add a `CONTRIBUTING.md` if you plan to accept community contributions.

---

If you'd like, I can now:
- create a GitHub repo and push these files (I can't access your GitHub without credentials) — I can provide exact `git` commands.
- scaffold a minimal `src/` module (featurizer + model pipeline).
- add a GitHub Actions workflow.
Tell me which of those you want next and I'll produce the files and commands.
